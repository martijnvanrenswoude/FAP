﻿CREATE TABLE [dbo].[Customer]
(
	[id] INT NOT NULL PRIMARY KEY, 
    [name] NVARCHAR(MAX) NULL, 
    [telephone_nr] INT NULL, 
    [postcode] NVARCHAR(6) NULL, 
    [house number] NVARCHAR(10) NULL, 
    [email] NVARCHAR(MAX) NULL
)
