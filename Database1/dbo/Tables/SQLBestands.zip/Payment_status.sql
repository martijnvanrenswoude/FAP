﻿CREATE TABLE [dbo].[Payment_status]
(
	[id] INT NOT NULL PRIMARY KEY, 
    [name] NVARCHAR(MAX) NULL, 
    [descriptiom] NVARCHAR(MAX) NULL
)
