﻿CREATE TABLE [dbo].[Inspector]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [name] NVARCHAR(MAX) NULL, 
    [surname] NVARCHAR(MAX) NULL, 
    [telephone_nr] INT NULL, 
    [postcode] NVARCHAR(6) NULL, 
    [house number] NVARCHAR(5) NULL,
	FOREIGN KEY (Id) REFERENCES Id(Id)
)
