﻿CREATE TABLE [dbo].[StandardQuestion]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [question] NVARCHAR(MAX) NULL
)
