﻿CREATE TABLE [dbo].[Department]
(
	[id] INT NOT NULL PRIMARY KEY, 
    [name] NVARCHAR(MAX) NULL, 
    [description] NVARCHAR(MAX) NOT NULL
)
